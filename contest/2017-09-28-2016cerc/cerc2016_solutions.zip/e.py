#!/usr/bin/python
from sys import stdin
k, n = [int(token) for token in stdin.readline().split(' ')]

def MakeTriple(a, b, c):
  return tuple(sorted([a, b, c]))

banned = set([0])
seen = set([MakeTriple(0, 1, k)])

def CheckTriple(a, b, c):
  assert a*a + b*b + c*c == k * (a*b + b*c + c*a) + 1

while n > 0:
  new_seen = seen.copy()
  for (a, b, c) in seen:
    CheckTriple(a, b, c)
    if a not in banned and b not in banned and c not in banned and a != b and b != c:
      banned.add(a)
      banned.add(b)
      banned.add(c)
      print a, b, c
      n = n - 1
      if n == 0: break
    for _ in range(3):
      d = k * (a + b) - c
      if d >= 0: new_seen.add(MakeTriple(a, b, d))
      a, b, c = b, c, a
  seen = new_seen
