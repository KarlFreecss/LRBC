import sys

def inv(x):
    y = len(x) * [0]
    for i in range(len(x)):
        y[x[i]] = i
    return y

def read():
    p = [0] + list(map(int, input().split()))    
    n = inv(p)
    return p, n

n = int(input())

pa, na = read()
pb, nb = read()

tail = set()
lcs = 0

for i in range(1, n + 1):
    if na[i] == 0 and nb[i] == 0:
        ja, jb = i, i
        while ja == jb and ja != 0:
            lcs += 1
            tail.add(ja)
            ja = pa[ja]
            jb = pb[jb]

sol = 0

for i in range(1, n + 1):
    if i not in tail:
        sol += na[i] != 0
        sol += nb[i] != 0

print(sol)

